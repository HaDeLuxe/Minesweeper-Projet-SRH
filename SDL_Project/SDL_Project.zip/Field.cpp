#include "Field.h"



Field::Field()
{
}

Field* Field::m_pInstance = NULL;


Field * Field::Instance()
{
	if (!m_pInstance) {
		m_pInstance = new Field;
	}
	return m_pInstance;
}

Field::~Field()
{
}

void Field::createPlayField(int pX, int pY)
{
	for (int y = 0; y < pY; y++) {
		std::vector<int> temp;
		std::vector<int> tempMine;
		for (int x = 0; x < pX; x++) {
			temp.push_back(1);
			tempMine.push_back(0);
		}
		field.push_back(temp);
		minesfield.push_back(tempMine);
	}
}

#pragma region Create Field and Renderer
void Field::createWindow() {
	win = SDL_CreateWindow("Minesweeper Adventure", 0, 20, 1920, 1080, SDL_WINDOW_SHOWN);
	if (win == nullptr) {
		std::cout << "SDL_CreateWindow Error: " << SDL_GetError() << std::endl;
		SDL_Quit();
	}
}

void Field::createRenderer() {
	ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
	if (ren == nullptr) {
		SDL_DestroyWindow(win);
		std::cout << "SDL_CreateRenderer Error: " << SDL_GetError() << std::endl;
		SDL_Quit();
	}
}
#pragma endregion

#pragma region Getter/Setter

SDL_Renderer * Field::getRenderer()
{
	return ren;
}

SDL_Window* Field::getWindow() {
	return win;
}

void Field::setRendererColor(int r, int g, int b, int a)
{
	SDL_SetRenderDrawColor(ren, r, g, b, a);
}

void Field::renderClear()
{
	SDL_RenderClear(ren);
}

#pragma endregion


void Field::calculatePlayerPos()
{
	for (int i = 0; i < field.size(); i++) {
		for (int m = 0; m < field[i].size(); m++) {
			if (field[i][m] == PLAYER) {
				playerXPos = m;
				playerYPos = i;
			}
		}
	}
}


#pragma region getter
int Field::getPlayerXPos()
{
	return playerXPos;
}

int Field::getPlayerYPos()
{
	return playerYPos;
}

int Field::getObjectAtCoord(int x, int y)
{
	return field[y][x];
}

#pragma endregion

void Field::enterObjectInField(int x, int y, int number)
{
	field[y][x] = number;
}

void Field::writeNumbers()
{

}




void Field::drawField()
{
	
	drawCl->drawRect(335, 165, 1250, 750);

	int r = 0;
	int c = 0;
	for (int i = 0; i < field.size(); i++) {
		for (int m = 0; m < field[i].size(); m++) {
			if (field[i][m] == BACKGROUND) {
				drawCl->drawRect(335 + c * 50, 165 + r * 50, 50, 50);
			}
			if (field[i][m] == WALL) {
				drawCl->drawRect(335 + c * 50, 165 + r * 50, 50, 50);
			}
			if (field[i][m] == PLAYER) {
				drawCl->drawRect(335 + c * 50, 165 + r * 50, 50, 50);
				drawCl->drawFillCircle(335 + c * 50, 165 + r * 50, 25);
			}
			c++;
			if (c >= field[r].size()) c = 0;
		}
		r++;
		if (r >= field.size()) r = 0;
	}

	SDL_RenderPresent(ren);
}
