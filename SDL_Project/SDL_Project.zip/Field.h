#pragma once
#include "Header.h"
#include "drawClass.h"



#define BACKGROUND 1
#define WALL 2
#define PLAYER 3

class Field
{


private:
	SDL_Window * win;
	SDL_Renderer *ren;
	int playerXPos;
	int playerYPos;

	static Field* instance;


	Field();
	Field(Field const&) {};
	Field& operator =(Field const&) {};
	static Field* m_pInstance;


	

public:
	drawClass*drawCl = new drawClass();
	std::vector<std::vector<int>> field;
	std::vector<std::vector<int>> minesfield;

	static Field* Instance();


	~Field();
	void createPlayField(int pX, int pY);
	void createWindow();
	void createRenderer();
	SDL_Renderer* getRenderer();
	SDL_Window* getWindow();

	void setRendererColor(int r, int g, int b, int a);
	void renderClear();

	void calculatePlayerPos(); //Gets the player coordinates

	int getPlayerXPos();
	int getPlayerYPos();

	int getObjectAtCoord(int x, int y);
	void enterObjectInField(int x, int y, int number);

	void writeNumbers();

	void drawField();
};



