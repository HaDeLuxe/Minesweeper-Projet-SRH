#pragma once
#include "Header.h"

#include "Menu.h"


enum class States {
	Start,
	Splashscreen,
	MainMenu,
	End
};

class GameManager
{
private:
	Menu* mainMenu = new Menu();
	States currentGameState = States::Start;
public:
	GameManager();
	~GameManager();

	void currentGameStatesInspector();
	void setStateToStart();
	void setStateToSplashscreen();
	void setStateToMainMenu();
	void setStateToEnd();


};

