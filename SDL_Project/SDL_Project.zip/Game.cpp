#include "Game.h"



Game::Game()
{
}


Game::~Game()
{
}


int Game::TTF_Initiate()
{
	if (TTF_Init() == -1) {
		std::cout << "TTF_Init: " << TTF_GetError() << std::endl;
		exit(2);
	}
}

TTF_Font * Game::OpenFont(const char * file, int ptsize)
{
	font = TTF_OpenFont(file, ptsize);

	if (!font) {
		printf("TTF_OpenFont: %s\n", TTF_GetError());
		// handle error
	}
	return font;
}


void Game::writeNumbers()
{
	std::cout << "1" << std::endl;
	TTF_Initiate();
	//std::cout << "TTF_Init()" << std::endl;
	//std::string fontfile = "D:\\SRH\\Programmierung 1\\Project\\SDL-Project-master\\SDL_ProjectOpenSans-Regular.ttf";
	std::string fontfile = "OpenSans-Regular.ttf";
	//std::cout << "Open font" << std::endl;
	OpenFont(fontfile.c_str(), 50);

	SDL_Texture* solidTexture;
	SDL_Rect solidRect;
	solidRect.x = 0;
	solidRect.y = 0;
	solidRect.h = 100;
	solidRect.w = 100;

	SDL_Color textColor = { 255, 255, 255, 255 };
	SDL_Surface * solid = TTF_RenderText_Solid(font, "Hallo, dad heien as nemme ee versuch", textColor);

	solidTexture = SDL_CreateTextureFromSurface(WINDOW->getRenderer(), solid);
	SDL_FreeSurface(solid);
	std::cout << "Text has been written out" << std::endl;
	SDL_RenderCopy(WINDOW->getRenderer(), solidTexture, &solidRect, &solidRect);

}


