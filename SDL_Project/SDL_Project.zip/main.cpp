#include "Header.h"

#include "Field.h"
#include "Textures.h"
#include "Game.h"
#include "Movement.h"
#include "drawClass.h"
#include "GameManager.h"


#define WINDOW Field::Instance()



Textures* textures;
Movement* movement;
Game* game;
GameManager * gameManager;

drawClass* draw;
SDL_Window *win;

void PollEvents();
void drawRect();




int main(int argc, char* argv[])
{
	if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) != 0) {
		SDL_Log("Unable to initialize SDL: %s", SDL_GetError());
		return 1;
	}

	textures = new Textures();
	movement = new Movement();
	game = new Game();
	draw = new drawClass();
	gameManager = new GameManager();

	win = WINDOW->getWindow();

	WINDOW->createWindow();
	WINDOW->createRenderer();
	WINDOW->createPlayField(25, 15);

	//textures->loadTexture("C:\\Users\\Pascal\\Desktop\\inf.jpg",  WINDOW->getRenderer());
	//textures->renderTexture(textures->getTex(),  WINDOW->getRenderer(), 0, 0);
	movement->moveRight();
	PollEvents();

	gameManager->setStateToStart();
	gameManager->currentGameStatesInspector();

	SDL_DestroyRenderer(WINDOW->getRenderer());
	SDL_DestroyWindow(win);
	SDL_Quit();


	return 0;
}

void drawRect() {
	
	draw->drawRect(10, 10, 25, 25);

}

void PollEvents() {
	bool closed = false;
	bool pressed = false;
	SDL_Event event;
	double i = 1;
	while (i) {
		while (SDL_PollEvent(&event)) {
			if (event.type == SDL_QUIT) {
				i = 0;
				break;
			}

			if (event.type == SDL_KEYDOWN) { // && event.key.repeat == 0
				switch (event.key.keysym.sym) {
				case SDLK_w:
					movement->moveUp();
					break;
				case SDLK_s:
					movement->moveDown();
					break;
				case SDLK_d:
					movement->moveRight();
					break;
				case SDLK_a:
					movement->moveLeft();
					break;
				}

			}
			if (event.type == SDL_MOUSEBUTTONUP) {
				int mouseX;
				int mouseY;
				switch (event.button.button) {
				case SDL_BUTTON_LEFT:
					std::cout << "Left Mouse Button Pressed" << std::endl;
					mouseX = event.motion.x;
					mouseY = event.motion.y;
					movement->moveAfterClick(mouseX, mouseY);
					break;
				}
			}
			WINDOW->setRendererColor(0, 0, 0, 255);
			WINDOW->renderClear();
			game->writeNumbers();
			WINDOW->drawField();
			//SDL_Delay(100);
			SDL_RenderPresent(WINDOW->getRenderer());

		}
	}
}