#include "drawClass.h"



drawClass::drawClass()
{
}


drawClass::~drawClass()
{
}

#pragma region object draw functions
void drawClass::drawRect(int x1, int y1, int x2, int y2)
{
	SDL_Rect rect;
	rect.h = y2;
	rect.w = x2;
	rect.x = x1;
	rect.y = y1;
	SDL_SetRenderDrawColor(FIELD->getRenderer(), 0, 255, 0, 255);
	SDL_RenderDrawRect(FIELD->getRenderer(), &rect);
}

void drawClass::drawFillRect(int x1, int y1, int x2, int y2)
{
	SDL_Rect rect;
	rect.h = y2;
	rect.w = x2;
	rect.x = x1;
	rect.y = y1;
	SDL_SetRenderDrawColor(FIELD->getRenderer(), 0, 255, 0, 255);
	SDL_RenderFillRect(FIELD->getRenderer(), &rect);
}

void drawClass::drawFillCircle(int x, int y, int radius)
{
	SDL_SetRenderDrawColor(FIELD->getRenderer(), 0, 255, 0, 255);
	for (int w = 0; w < radius * 2; w++)
	{
		for (int h = 0; h < radius * 2; h++)
		{
			int dx = radius - w; // horizontal offset
			int dy = radius - h; // vertical offset
			if ((dx*dx + dy * dy) <= (radius * radius))
			{
				SDL_RenderDrawPoint(FIELD->getRenderer(), x + 25 + dx, y + 25 + dy);
			}
		}
	}
}
#pragma endregion Hier sind die Funktionen um Objekte wie Kreise und Rechtecke zu zeichnen.
