#pragma once
#include "Header.h"
#include "Field.h"

#define FIELD Field::Instance()


class drawClass
{
public:
	drawClass();
	~drawClass();

#pragma region object draw functions
	void drawRect(int x1, int y1, int x2, int y2);
	void drawFillRect(int x1, int y1, int x2, int y2);
	void drawFillCircle(int x, int y, int radius);
#pragma endregion Hier sind die Funktionen um Objekte wie Kreise und Rechtecke zu zeichnen.
};

