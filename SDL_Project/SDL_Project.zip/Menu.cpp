#include "Menu.h"



Menu::Menu()
{
}


Menu::~Menu()
{
}

void Menu::RenderMenu()
{
	FIELD->renderClear();
	draw->drawFillRect(100, 100, 1820, 980);
	SDL_RenderPresent(FIELD->getRenderer());
	SDL_Delay(3000);
}
