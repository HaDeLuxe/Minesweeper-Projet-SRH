#include "GameManager.h"



GameManager::GameManager()
{
}


GameManager::~GameManager()
{
}

void GameManager::currentGameStatesInspector()
{
	switch (currentGameState) {
	default:
	case States::Start:
		mainMenu->RenderMenu();
		break;
	case States::Splashscreen:
		break;
	case States::MainMenu:
		break;
	case States::End:
		break;
	}

}

void GameManager::setStateToStart()
{
	currentGameState = States::Start;
}

void GameManager::setStateToSplashscreen()
{
	currentGameState = States::Splashscreen;
}

void GameManager::setStateToMainMenu()
{
	currentGameState = States::MainMenu;
}

void GameManager::setStateToEnd()
{
	currentGameState = States::End;
}
