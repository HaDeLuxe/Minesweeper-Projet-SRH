#pragma once
#include "Header.h"
#include "Field.h"
#include "drawClass.h"


#define FIELD Field::Instance()

class Menu
{
private:

	drawClass * draw = new drawClass();
public:
	Menu();

	~Menu();

	void RenderMenu();


};

