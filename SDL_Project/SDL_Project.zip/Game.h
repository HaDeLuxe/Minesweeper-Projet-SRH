#pragma once

#include "Header.h"
#include "Textures.h"
#include "Field.h"

//#include "Textures.h"

#define WINDOW Field::Instance()


class Game
{
private:

	TTF_Font * OpenFont(const char *file, int ptsize);
	TTF_Font *font;
public:
	Game();
	~Game();
	int TTF_Initiate();
	void writeNumbers();
	SDL_Texture* SurfaceToTexture(SDL_Surface* surf);

};

